# Copyright (c) Facebook, Inc. and its affiliates.
from .transformer_decoder.video_mask2former_transformer_decoder import VideoMultiScaleMaskedTransformerDecoder
