# Copyright (c) Facebook, Inc. and its affiliates.
from .video_mask2former_transformer_decoder import VideoMultiScaleMaskedTransformerDecoder
