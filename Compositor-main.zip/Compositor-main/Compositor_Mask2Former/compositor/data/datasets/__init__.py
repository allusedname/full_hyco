from . import (
    register_partimagenet_semseg,
)