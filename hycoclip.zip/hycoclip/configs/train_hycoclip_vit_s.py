from .train_hycoclip_vit_l import dataset, model, optim, train


model.visual.arch = "vit_small_mocov3_patch16_224"
