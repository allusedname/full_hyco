from .train_hycoclip_vit_l import dataset, model, optim, train


model.visual.arch = "vit_base_patch16_224"
